/**
 * Who: Caleb Slater
 * What: Read file then output it line by line
 * When: 2015-09-11
 * Where: CS 2240
 * How: "$./A0CS224Fall2015.out"
 * If want to read a file other than AllCountries.dat supply the filename as 2nd argument ex: "$./A0CS224Fall2015.out use_this_file_hint_hint"
**/
#include "apue.h"
#include <fcntl.h>
#include "error.c"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "functions.c"

//global variables
static char DEFAULT_FILE[] = "AllCountries.dat";

//end global variables

int main(int argc, char *argv[]) {
	char *fileName;
	if( argc > 1 ) {
		fileName = argv[1];
	} else {
		fileName = DEFAULT_FILE;
	}
	int i;
	for( i = 0; i < 241; i++ ) {
		char *line = gimmeALine(fileName);
		// countryPtr country;
		// country = fillAStruct(line);
		// printf("\n--STRUCT--\n\tID:%d\n\tCode:%s\n\tName:%s\n\tCont:%s\n\tRegion:%s\n--END STRUCT--\n",
		// 	country->id, country->code, country->name,
		// 	country->continent, country->region
		// );
		printf("\nLine[%d] currentLineNum:%d\n\t'%s'\n", i+1, currentLineNum, line);
	}
	printf("\n---------------------\nDONE\n");

	return 0;
} //end main()
