/**
* Who: Caleb Slater
* What: A4
* When: 2015-10-01
* Where: CS 2240
* How: "$./b.out"
* Memory play
**/
#include "apue.h"
#include <fcntl.h>
// #include "error.c"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

#include "functions.c"

//global variables
//end global variables

int main(int argc, char *argv[]) {
	static MyBlock **blocks;

	

    return EXIT_SUCCESS;
} //end main()
