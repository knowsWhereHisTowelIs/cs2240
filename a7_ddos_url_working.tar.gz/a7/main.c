/**
 * Who: Caleb Slater
 * What: A7
 * When: 2015-12-15
 * Where: CS 2240
 * How: "$./a.out"
 * 127.0.0.1:4000
 **/

/**
 * Sources http://ods.com.ua/win/eng/program/socket/socketprg.html
 * http://stackoverflow.com/questions/28763469/display-image-from-web-server-in-c
 * http://www.jbox.dk/sanos/webserver.htm
 * http://stackoverflow.com/questions/3060950/how-to-get-ip-address-from-sock-structure-in-c
 */

#include "functions.h"
#define MAX_HITS 100
#define BLOCKED_CLIENT_STATUS -1
#define ACCEPTED_CLIENT_STATUS 1
int clientsSize = 0;
int clientsLastIndex = 0;
clientsAccountType **clients;

int main() {
    int one = 1, client_fd;
    struct sockaddr_in svr_addr, cli_addr;
    socklen_t sin_len = sizeof (cli_addr);

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        err(1, "can't open socket");
    }

    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof (int));

    svr_addr.sin_family = AF_INET;
    svr_addr.sin_addr.s_addr = INADDR_ANY;
    svr_addr.sin_port = htons(PORT);

    if (bind(sock, (struct sockaddr *) &svr_addr, sizeof (svr_addr)) == -1) {
        close(sock);
        err(1, "Can't bind");
    }

    listen(sock, 5);
    fprintf(stderr, "\nStarted Server... listening\n");
    while (1) {
        client_fd = accept(sock, (struct sockaddr *) &cli_addr, &sin_len);
        if (client_fd == -1) {
            perror("Can't accept");
            continue;
        }
        fprintf(stderr, "\n----------------------------------------------------------\nHandling ip:' %d.%d.%d.%d '", 
            ( cli_addr.sin_addr.s_addr&0xFF ),
            ( cli_addr.sin_addr.s_addr&0xFF00 ) >>8,
            ( cli_addr.sin_addr.s_addr&0xFF0000 ) >>16,
            ( cli_addr.sin_addr.s_addr&0xFF000000 ) >>24
        );
        
        int clientStatus = updateClients(cli_addr.sin_addr.s_addr);
        char *msg;
        //DDOS PROTECTION
        if( clientStatus == ACCEPTED_CLIENT_STATUS ) {
            msg = "ACCEPTED";
            FILE *f = fdopen(client_fd, "a+");
            processRequest(f);
            fclose(f);
        } else {
            msg = "BLOCKED";
            close(client_fd); //must close so process isn't stuck
        }
        fprintf(stderr, "\n%s connection\n", msg);
    }
}

/**
 * 
 * @param ip
 * @return status -1 blocked, else 1 for success
 */
int updateClients(int ip){ 
    int status = 0;
    boolean hasFoundClient = false;
    
    for(int i = 0; i < clientsLastIndex; i++){
        fprintf(stderr, "\nClient[%d] IP:' %d.%d.%d.%d ' ",
            i, 
            ( clients[i]->ip&0xFF ),
            ( clients[i]->ip&0xFF00 ) >>8,
            ( clients[i]->ip&0xFF0000 ) >>16,
            ( clients[i]->ip&0xFF000000 ) >>24
        );
        if( clients[i]->ip == ip ) {
            hasFoundClient = true;
            fprintf(stderr, "\nFound client w/hits:%d > %d = %d", clients[i]->hits, MAX_HITS, clients[i]->hits > MAX_HITS);
            // if too many hits blacklist
            if( clients[i]->hits > MAX_HITS ) {
                fprintf(stderr, " CLIENT BLOCKED");
                //report as blocked
                status = BLOCKED_CLIENT_STATUS;
            } else {
                fprintf(stderr, " CLIENT ACCEPTED");
                //update hits
                clients[i]->hits++;
                status = ACCEPTED_CLIENT_STATUS;
            }
            break;
        }
    }
    
    //hasn't found client so create client
    if( hasFoundClient == false ) {
        if( clientsLastIndex == clientsSize ) {
            clientsSize += 50;
            clients = (clientsAccountType **) realloc( clients, ( clientsSize * sizeof(clientsAccountType*) ) );
        }
        
        fprintf(stderr, "\nAdding Client[%d] clientSize:%d IP:' %d.%d.%d.%d ' ",
            clientsLastIndex, 
            clientsSize,
            ( ip&0xFF ),
            ( ip&0xFF00 ) >>8,
            ( ip&0xFF0000 ) >>16,
            ( ip&0xFF000000 ) >>24
        );

        clientsAccountType client;
        client.ip = ip;
        client.hits++;

        clientsAcountPtr clientPtr = malloc( sizeof(clientsAccountType) );
        *clientPtr = client;
        clients[clientsLastIndex] = clientPtr;

        status = ACCEPTED_CLIENT_STATUS;
        clientsLastIndex++;
    }
    
    return status;
}

