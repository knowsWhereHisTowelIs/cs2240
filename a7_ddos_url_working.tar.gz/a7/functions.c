#include "functions.h"

int processRequest(FILE *responseFile) {
    char buffer[BUFFER_SIZE];
    char *method, *path, *protocol;
    struct stat statbuf;
    
    if ( !fgets(buffer, sizeof (buffer), responseFile) ) { 
        return -1;
    }
    
    char *requestCopy = malloc(strlen(buffer) + 1);
    strncpy(requestCopy, buffer, strlen(buffer) + 1);
    
    method      = strtok_r(requestCopy, " ", &requestCopy);
    path        = strtok_r(requestCopy, " ", &requestCopy);
    protocol    = strtok_r(requestCopy, "\r", &requestCopy);
    
    if (!method || !path || !protocol) {
        return -1;
    }
    
    //set index file if no file selected
    if ( path[0] == '/' ) {
        if( strlen(path) == 1 ) {
            strcpy(path, "/index.html");
        } 
        
        //set relative path to htdocs
        char *tmp = malloc( 1+strlen(path) );
        strcpy(tmp, HTDOCS_RELATIVE_PATH); //Put str2 or anyother string that you want at the begining
        strcat(tmp, path);  //concatenate previous str1
        strcpy(path, tmp);
        free(tmp);
    }
    fprintf(stderr, "\nRequested File: %s", path);
    
    if (stat(path, &statbuf) < 0) {
        fprintf(stderr, "\nFile Not Found sending error");
        sendError(responseFile, 404, "Not Found", NULL, "File not found.");
    } else {
        fprintf(stderr, "\nFound file sending...");
        sendFile(responseFile, path, &statbuf);
    }
    
//    if( 0 ) {
//        sampleHtmlResponse(responseFile);
//    } else {
//        sampleFileResponse(responseFile);
//    }
    return 0;
}

void sendFile(FILE *responseFile, char *path, struct stat *statbuf) {
    FILE *file = fopen(path, "r");
    int n;
    char buffer[BUFFER_SIZE];
    char *msg;
    
    if (!file ) {
        msg = "404 File not found.";
        sendError(responseFile, 403, "Forbidden", NULL, msg);
    } else if( stat(path, statbuf) < 0 ) {
        msg = "404 File not found.";
        sendError(responseFile, 403, "Forbidden", NULL, msg);
    } else if ( S_ISDIR(statbuf->st_mode) ) {
        msg = "Don't look at my directory.";
        sendError(responseFile, 403, "Forbidden", NULL, msg);
    } else {
        msg = "Found File";
        int length = S_ISREG(statbuf->st_mode) ? statbuf->st_size : -1;
        sendHeaders(responseFile, 200, "OK", NULL, getMimeType(path), length);
        
        //printf("\n-------%s length:%d-------\n", path, length);
        while ((n = fread(buffer, 1, sizeof(buffer), file)) > 0) {
            fwrite(buffer, 1, n, responseFile);
            //printf("%s", buffer);
        }
        //printf("\nEND\n");
        fclose(file);
    }
    fprintf(stderr, "\n%s", msg);
}

void sendError(FILE *responseFile, int status, char *title, char *extra, char *text) {
    sendHeaders(responseFile, status, title, extra, getMimeType(".html"), 0);
    fprintf(responseFile, "<HTML><HEAD><TITLE>%d %s</TITLE></HEAD>\r\n", status, title);
    fprintf(responseFile, "<BODY><H4>%d %s</H4>\r\n", status, title);
    fprintf(responseFile, "%s\r\n", text);
    fprintf(responseFile, "</BODY></HTML>\r\n");
}

void sampleHtmlResponse(FILE *responseFile) {
    char *content = "<!DOCTYPE html><html><head><title>Bye-bye baby bye-bye</title>"
        "<style>body { background-color: #111 }"
        "h1 { font-size:4cm; text-align: center; color: black;"
        " text-shadow: 0 0 2mm red}</style></head>"
        "<body><h1>Goodbye, world!</h1></body></html>";
    sendHeaders(responseFile, 200, "OK", NULL, getMimeType(".html"), strlen(content));
    fprintf(responseFile, "%s", content);
    //printf("SampleHTMLNEW()\n%s", content);
}

void sampleFileResponse(FILE *responseFile) {
    //char *path = "/home/mini/Dropbox/current_semester/cs2240/a7/sound.wav";
    char *path = "sound.wav";
    FILE *file = fopen(path, "r");
    struct stat statbuf;
    int n;
    char buffer[BUFFER_SIZE];
        
    if (!file ) {
        char *msg = "Access denied.";
        sendHeaders(responseFile, 403, "Forbidden", NULL, getMimeType(".html"), strlen(msg));
        fprintf(responseFile, "%s", msg);
    } else if( stat(path, &statbuf) < 0 ) {
        printf("\n\nERROR\n\n");
    } else if ( S_ISDIR(statbuf.st_mode) ) {
        printf("\nIs directory");
    } else {
        int length = S_ISREG(statbuf.st_mode) ? statbuf.st_size : -1;
        sendHeaders(responseFile, 200, "OK", NULL, getMimeType(path), length);
        
        //printf("\n-------%s length:%d-------\n", path, length);
        while ((n = fread(buffer, 1, sizeof(buffer), file)) > 0) {
            fwrite(buffer, 1, n, responseFile);
            //printf("%s", buffer);
        }
        //printf("\nEND\n");
        fclose(file);
    }
}

void sendHeaders(FILE *f, int status, char *title, char *extra, char *mime, int length) {
    fprintf(f, "%s %d %s\r\n", PROTOCOL, status, title);
    fprintf(f, "Server: %s\r\n", SERVER);
    if (extra) fprintf(f, "%s\r\n", extra);
    if (mime) fprintf(f, "Content-Type: %s\r\n", mime);
    if (length >= 0) fprintf(f, "Content-Length: %d\r\n", length);
    fprintf(f, "Connection: close\r\n");
    fprintf(f, "\r\n");
}

char *getMimeType(char *name) {
    char *ext = strrchr(name, '.');
    if (!ext) return NULL;
    if (strcmp(ext, ".html") == 0 || strcmp(ext, ".htm") == 0) return "text/html";
    if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(ext, ".gif") == 0) return "image/gif";
    if (strcmp(ext, ".png") == 0) return "image/png";
    if (strcmp(ext, ".css") == 0) return "text/css";
    if (strcmp(ext, ".au") == 0) return "audio/basic";
    if (strcmp(ext, ".wav") == 0) return "audio/wav";
    if (strcmp(ext, ".avi") == 0) return "video/x-msvideo";
    if (strcmp(ext, ".mpeg") == 0 || strcmp(ext, ".mpg") == 0) return "video/mpeg";
    if (strcmp(ext, ".mp3") == 0) return "audio/mpeg";
    return NULL;
}