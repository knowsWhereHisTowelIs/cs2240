#ifndef MAKEARGV_H
#define MAKEARGV_H

int makeargv(char *s,char *delimeters,char ***argvp);




#endif

