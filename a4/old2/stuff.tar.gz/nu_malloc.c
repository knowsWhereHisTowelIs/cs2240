/**
* Who: Caleb Slater
* What: A4
* When: 2015-10-01
* Where: CS 2240
* How: "$./a.out"
* Memory play
**/

#include "nu_malloc.h"

/**
 * Allocate @size in memory
 * return pointer to block we created
**/
void *nu_malloc(size_t size) {
    struct block_meta *block;
    // TODO: align size?

    if (size <= 0) {
        return NULL;
    }

    if (!global_base) { // First call.
        block = request_space(NULL, size);
        if (!block) {
            return NULL;
        }
        global_base = block;
    } else {
        struct block_meta *last = global_base;
        block = find_free_block(&last, size);
        if (!block) { // Failed to find free block.
            block = request_space(last, size);
            if (!block) {
                return NULL;
            }
        } else {      // Found free block
            // TODO: consider splitting block here.
            block->free = 0;
            block->magic = 0x77777777;
        }
    }

    return (block+1);
}

/**
 * frees a pointer in memory
**/
void nu_free(void *ptr) {
    //if pointer isn't set don't do anything
    if (!ptr) {
        return;
    }

    // TODO: consider merging blocks once splitting blocks is implemented.
    struct block_meta* block_ptr = get_block_ptr(ptr);
    assert(block_ptr->free == 0);
    assert(block_ptr->magic == 0x77777777 || block_ptr->magic == 0x12345678); //set debugging locations
    block_ptr->free = 1;
    block_ptr->magic = 0x55555555; //set debugging locations
}

/**
 * frees a pointer in memory
**/
void *nu_realloc(void *ptr, size_t size) {
    if (!ptr) {
        // NULL ptr. realloc should act like malloc.
        return nu_malloc(size);
    }

    struct block_meta* block_ptr = get_block_ptr(ptr);
    if (block_ptr->size >= size) {
        // We have enough space. Could free some once we implement split.
        return ptr;
    }

    // Need to really realloc. Malloc new space and free old space.
    // Then copy old data to new space.
    void *new_ptr;
    new_ptr = nu_malloc(size);
    if (!new_ptr) {
        return NULL; // TODO: set errno on failure.
    }
    memcpy(new_ptr, ptr, block_ptr->size);
    nu_free(ptr);
    return new_ptr;
}

/**
 * frees a pointer in memory
**/
void *nu_calloc(size_t nelem, size_t elsize) {
    size_t size = nelem * elsize; // TODO: check for overflow.
    void *ptr = nu_malloc(size);
    memset(ptr, 0, size);
    return ptr;
}
