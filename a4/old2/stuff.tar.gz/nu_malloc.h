#ifndef nu_malloc_h
    #define nu_malloc_h
    #define META_SIZE sizeof(struct block_meta)

    #include <stdio.h>
    #include <assert.h>
    #include <string.h>
    #include <sys/types.h>
    #include <unistd.h>

    void *nu_malloc(size_t size);
    void nu_free(void *ptr);
    void *nu_realloc(void *ptr, size_t size);
    void *nu_calloc(size_t nelem, size_t elsize);

    struct block_meta {
        size_t size;
        struct block_meta *next;
        int free;
        int magic; // For debugging only. TODO: remove this in non-debug mode.
    };

    void *global_base = NULL;

    struct block_meta *find_free_block(struct block_meta **last, size_t size) {
        struct block_meta *current = global_base;
        while (current && !(current->free && current->size >= size)) {
            *last = current;
            current = current->next;
        }
        return current;
    }

    struct block_meta *request_space(struct block_meta* last, size_t size) {
        struct block_meta *block;
        block = sbrk(0);
        void *request = sbrk(size + META_SIZE);
        assert((void*)block == request); // Not thread safe.
        if (request == (void*) -1) {
            return NULL; // sbrk failed.
        }

        if (last) { // NULL on first request.
            last->next = block;
        }
        block->size = size;
        block->next = NULL;
        block->free = 0;
        block->magic = 0x12345678;
        return block;
    }

    struct block_meta *get_block_ptr(void *ptr) {
        return (struct block_meta*)ptr - 1;
    }

#endif /* nu_malloc_h */
