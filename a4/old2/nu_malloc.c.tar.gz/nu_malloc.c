//
//  nu_malloc.c
//  malloc_tutorial
//
//  Created by Benjamin Masters on 10/13/15.
//  Copyright © 2015 Benjamin Masters. All rights reserved.
//

#include "nu_malloc.h"

void *global_base = NULL;

blockHeaderPtr findFreeBlock(blockHeaderPtr *last, size_t size) {
    blockHeaderPtr current = global_base;
    while (current && !(current->free && current->size >= size)) {
        *last = current;
        current = current->next;
    }
    return current;
}

blockHeaderPtr requestSpace(blockHeaderPtr  last, size_t size) {
    blockHeaderPtr block;
    block = sbrk(0);
    void *request = sbrk(size + BLOCK_HEADER_SIZE);
    assert((void*) block == request); // Not thread safe.
    if (request == (void*) -1) {
        return NULL; // sbrk failed.
    }

    if (last) { // NULL on first request.
        last->next = block;
    }
    block->size = size;
    block->next = NULL;
    block->free = 0;
    block->magic = 0x12345678;
    return block;
}

blockHeaderPtr getBlockPtr(void *ptr) {
    return (blockHeaderPtr )ptr - 1;
}

void *nu_malloc(size_t size) {
    blockHeaderPtr block;
    // TODO: align size?

    if (size <= 0) {
        return NULL;
    }

    if (!global_base) { // First call.
        block = requestSpace(NULL, size);
        if (!block) {
            return NULL;
        }
        global_base = block;
    } else {
        blockHeaderPtr last = global_base;
        block = findFreeBlock(&last, size);
        if (!block) { // Failed to find free block.
            block = requestSpace(last, size);
            if (!block) {
                return NULL;
            }
        } else {      // Found free block
            // TODO: consider splitting block here.
            block->free = 0;
            block->magic = 0x77777777;
        }
    }

    return(block+1);
}

void nu_free(void *ptr) {
    if (!ptr) {
        return;
    }

    // TODO: consider merging blocks once splitting blocks is implemented.
    blockHeaderPtr  block_ptr = getBlockPtr(ptr);
    assert(block_ptr->free == 0);
    assert(block_ptr->magic == 0x77777777 || block_ptr->magic == 0x12345678);
    block_ptr->free = 1;
    block_ptr->magic = 0x55555555;
}

void *nu_realloc(void *ptr, size_t size) {
    if (!ptr) {
        // NULL ptr. realloc should act like malloc.
        return nu_malloc(size);
    }

    blockHeaderPtr  block_ptr = getBlockPtr(ptr);
    if (block_ptr->size >= size) {
        // We have enough space. Could free some once we implement split.
        return ptr;
    }

    // Need to really realloc. Malloc new space and free old space.
    // Then copy old data to new space.
    void *new_ptr;
    new_ptr = nu_malloc(size);
    if (!new_ptr) {
        return NULL; // TODO: set errno on failure.
    }
    memcpy(new_ptr, ptr, block_ptr->size);
    nu_free(ptr);
    return new_ptr;
}

void *nu_calloc(size_t nelem, size_t elsize) {
    size_t size = nelem * elsize; // TODO: check for overflow.
    void *ptr = nu_malloc(size);
    memset(ptr, 0, size);
    return ptr;
}
